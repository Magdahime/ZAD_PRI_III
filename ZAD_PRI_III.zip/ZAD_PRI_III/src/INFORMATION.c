#include "main_menu.h"
#include "information_header.h"
struct node * add_information(struct node * node1)
{
        printf("Dodajesz informacje o przedstawieniu.\n");
        while (add_title (node1));
        while(add_type(node1));
        while(add_opinion(node1));
        while(add_actors(node1));
        return (node1);
}
int add_actors(struct node *node1)
{
        clean();
        int i =0;
        char **actor_table = malloc(sizeof(char*)*MAX_ROWS);
        printf("Dodajesz imiona i nazwiska aktorów głównych (MAX 2 aktorów)\n");
        do {
                actor_table[i]= malloc(sizeof(char)*MAX_CHAR);
                fscanf(stdin,"%[^\n]s", actor_table[i]);
                if(!if_string(actor_table[i])) {
                        printf("Pomyślnie zapisano %d aktora\n", i+1);
                        strcpy(node1->actors[i],actor_table[i]);
                        clean();
                        ++i;
                }else{
                        printf("Podałeś nieprawidłowe dane. Spróbuj jeszcze raz.\n\n");
                        return(1);
                }
        } while (i<MAX_ROWS);
        for(i=0; i<MAX_ROWS; i++)
                free(actor_table[i]);
        return(0);
}
int add_title (struct node *node1)
{
        char information_array[MAX_CHAR];
        clean();
        printf("Podaj tytuł:\n");
        fscanf(stdin, "%[^\n]s", information_array);
        if(if_string(information_array))
        {
                printf("Nie udało się zapisać tytułu.\n");
                return(1);
        }else {
                strcpy(node1->title,information_array);
                printf("Pomyślnie zapisano tytuł!\n");
                return(0);
        }
}

int add_type (struct node *node1)
{
        int type;
        printf("Podaj rodzaj przedstawienia\n");
        printf("Masz do wyboru: PRZEDSTAWIENIE(1), OPERA(2), OPERETKA(3), BALET(4), PANTOMIMA(5)\n" );
        printf("Pamiętaj, żeby wybrać odpowiedni numer!\n");
        type = if_enum();
        if(type ==-1)
        {
                printf("Nie udało się zapisać typu przedstawienia\n");
                return(1);
        }else{
                node1->showtype = type;
                printf("Pomyślnie zapisano typ przedstawienia!\n");
                return(0);
        }
}
int add_opinion( struct node *node1)
{
        unsigned int opinion;
        printf("Podaj ogólną opinię o przedstawieniu (1-100)\n");
        if (scanf("%ud",&opinion)!=0 && opinion<=100)
        {
                node1->opinion = opinion;
                printf("Pomyślnie zapisano opinię!\n");
                return(0);
        }else{
                printf("Podano nieprawidłową wartość.\n");
                clean();
                return(1);
        }
}
void free_the_memory(struct node *element)
{
        if(element)
        {
                free(element);
                element = NULL;
        }
}
int if_string(char *information_array)
{
        for(int i =0; i<strlen(information_array); i++)
        {
                if(isdigit(*(information_array+i)) != 0)
                        return (1);
        }
        return (0);
}
int if_enum(void)
{
        int type =0;
        if(scanf("%d",&type)<=0)
        {
                clean();
                printf("Podałeś coś innego. Spróbuj jeszcze raz\n");
                return(-1);
        }
        if(type>5)
        {
                clean();
                printf("Podałeś coś innego. Spróbuj jeszcze raz\n");
                return(-1);
        }
        return (type);
}
void print_information(struct node *node1)
{
static char *shows[] = {"ERROR","PRZEDSTAWIENIE", "OPERA", "OPERETKA", "BALET", "PANTOMIMA"};
        if (node1 !=NULL)
        {
                printf("\n\n************************************\n");
                printf("*TYTUŁ:\t%s\n",node1->title);
                printf("*TYP:\t%s\n",shows[node1->showtype]);
                printf("*OPINIA:%d\n",node1->opinion);
                for(int i=0; i<MAX_ROWS; i++)
                        printf("*AKTORZY:%s\n",node1->actors[i]);
                printf("************************************\n\n");
        }
}
void clean(void)
{
        char c;
        do
        {
                c = getchar();
        } while(c!= '\n' && c!= EOF);
}

void delete_end_of_line(char * string){
        for(int i =0; i<strlen(string); i++)
        {
                if(string[i]=='\n')
                        string[i]='\0';
        }
}
