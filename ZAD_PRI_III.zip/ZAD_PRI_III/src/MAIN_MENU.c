#include "list_header.h"
#include "information_header.h"
#include "main_menu.h"
#include "file_header.h"
int main (void)
{
        user_interface();
        return (0);
}
void user_interface(void)
{
        int ans;
        struct node * head= NULL;
        struct node * tail= NULL;
        printf("***************Witaj w bazie danych Teatru Starego.***************\n\n");
        while(1)
        {
                printf("Drogi użytkowniku co chcesz zrobić?:\n\n");
                printf("************************************************\n");
                printf("OBSŁUGA LISTY:");
                printf("\n*[1]\tDodaj element do istniejącej listy.(na początku)");
                printf("\n*[2]\tUsuń element.");
                printf("\n*[3]\tWyszukaj element.");
                printf("\n*[4]\tPosortuj elementy po opinii.");
                printf("\n*[5]\tPosortuj elementy po typie przedstawienia.");
                printf("\n*[6]\tPolicz elementy.");
                printf("\n*[7]\tEdytuj element.");
                printf("\n*[8]\tWyświetl elementy listy.\n");
                printf("************************************************\n");
                printf("OBSŁUGA DANYCH:");
                printf("\n*[9]\tPokaż alfabetyczną listę tytułów.(aktualnie na liście)");
                printf("\n*[10]\tPokaż aktualną listę zatrudnionych aktorów.\n");
                printf("************************************************\n");
                printf("OBSŁUGA PLIKÓW: ");
                printf("\n*[11]\tWczytaj dane z pliku tekstowego.");
                printf("\n*[12]\tZapisz dane do pliku tekstowego.");
                printf("\n*[13]\tWczytaj dane z pliku binarnego.");
                printf("\n*[14]\tZapisz dane do pliku binarnego.");
                printf("\n\n*[15]\tWyjście\n\n");
                printf("Wprowadź cyfrę:__");
                if(scanf("%d",&ans) ==1)
                {
                        switch(ans)
                        {
                        case (1):
                        {
                                clrscrs();
                                head = add_element(head, tail);
                                break;
                        }
                        case (2):
                        {
                                clrscrs();
                                delete_element_name(head,tail);
                                break;
                        }
                        case (3):
                        {
                                clrscrs();
                                struct node * temp = search_element(head,tail);
                                print_information(temp);
                                break;
                        }
                        case (4):
                        {
                                clrscrs();
                                head = sorting_list(&head,compare_opinion);
                                break;
                        }
                        case (5):
                        {
                                clrscrs();
                                head = sorting_list(&head,compare_enum);
                                break;
                        }
                        case (6):
                        {
                                clrscrs();
                                int size = list_size(head);
                                printf("\n\nRozmiar tej listy wynosi %d\n\n\n",size);
                                break;
                        }
                        case (7):
                        {
                                struct node * temp = search_element(head, tail);
                                if(temp == NULL) {
                                        printf("Nie znaleziono takiego elementu.\n");
                                }else
                                        edit_element(temp);
                                break;
                        }
                        case (8):
                        {
                                clrscrs();
                                show(head);
                                break;
                        }
                        case (9):
                        {
                                alphabetical_order(head);
                                break;
                        }
                        case (10):
                        {
                                clrscrs();
                                char** name_actors= make_actor_list();
                                search_actor(name_actors, head);
                                break;
                        }
                        case (11):
                        {
                                clrscrs();
                                FILE * file = from_the_file_t();
                                while(checking_file(file)==0)
                                {
                                        struct node * element =load_data(file);
                                        if(!element)
                                        {
                                                printf("Koniec pliku bądź plik uszkodzony.\n");
                                        }else{
                                                head= unite(head,element,tail);
                                        }
                                }
                                fclose(file);
                                break;
                        }
                        case (12):
                        {
                                clrscrs();
                                save_data_to_file(head, tail);
                                break;
                        }
                        case (13):
                        {
                                clrscrs();
                                size_t size_struct = sizeof(struct node);
                                FILE * file = from_the_file_b();
                                long int fsize = how_many_items(size_struct, file);
                                for(int i =0; i<fsize; i++)
                                {
                                        struct node * new_element = load_binary_data(file, size_struct);
                                        head = unite(head, new_element, tail);
                                }
                                break;
                        }
                        case (14):
                        {
                                clrscrs();
                                save_to_binary(head);
                                break;
                        }
                        case (15):
                        {
                                clrscrs();
                                struct node *current=head;
                                while(current != NULL)
                                {
                                        current = current->next;
                                        free_the_memory(current->prev);
                                }
                                free_the_memory(current);
                                exit(1);
                        }
                        default:
                        {
                                printf("Przykro mi nie ma opcji %d\n",ans);
                                printf("Spróbuj jeszcze raz...\n\n");
                                break;
                        }
                        }
                }

        }
}
