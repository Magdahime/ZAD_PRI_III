#include "main_menu.h"
#include "file_header.h"
FILE * from_the_file_t(void)
{
        FILE * file;
        char file_name[MAX_CHAR];
        do {
                printf("Wczytywanie danych z pliku tekstowego\n");
                printf("Podaj nazwę pliku\n");
                scanf("%s",file_name);
                file = opening_the_file_read_t(file_name);
        } while (file == NULL);
        return(file);
}
int print_data_to_file(struct node * head, FILE * file,struct node *tail)
{
        if(head==NULL) {
                printf("Lista jest pusta\n");
                return(1);
        }else{
                struct node * temp = head;
                while(temp != NULL) {
                        int i = 0;
                        fprintf(file, "{\n\"TYTUŁ\":\"%s\",\n",temp->title);
                        fprintf(file, "\"TYP\":%d,\n",temp->showtype);
                        fprintf(file, "\"OPINIA\":%d,\n",temp->opinion);
                        fprintf(file,"\"AKTORZY\":\"%s\",\n",temp->actors[i]);
                        fprintf(file,"\"AKTORZY\":\"%s\",\n}\n",temp->actors[i+1]);
                        temp=temp->next;
                }
        }
        return(0);
}
void save_data_to_file (struct node * head,struct node * tail)
{
        char file_name[MAX_CHAR];
        FILE * file;
        do {
                printf("Zapisujesz dane do pliku tekstowego.\n");
                printf("Podaj nazwę pliku do którego chcesz zapisać.\n");
                scanf("%s",file_name);
                file = fopen(file_name, "at");
                if (file == NULL)
                {
                        printf("Przykro mi nie można otworzyć pliku.\n");
                }
                printf("Udało się otworzyć plik!\n");
        } while (file == NULL);
        int result = print_data_to_file(head, file, tail);
        if(result)
        {
                printf("Błąd zapisu.\n\n\n");
        }else
                printf("Pomyślnie zapisano\n\n\n");
        fclose(file);
}
struct node * load_data (FILE *file)
{
        bool result;
        char title_key[]="\"TYTUŁ\":";
        char type_key[]="\"TYP\":";
        char opinion_key[]="\"OPINIA\":";
        char actor_key[]="\"AKTORZY\":";
        struct node * new_element = malloc(sizeof(struct node));
        result = get_the_char('{',file) && is_string(title_key, new_element->title,file)&& is_enum(type_key,new_element,file)&&is_opinion(opinion_key, new_element, file)&&is_string(actor_key, new_element->actors[0],file)&&is_string(actor_key, new_element->actors[1],file)&&get_the_char('}',file);
        if(!result) {
                free_the_memory(new_element);
                return (NULL);
        }
        print_information(new_element);
        return(new_element);
}
bool is_string (char* string_key, char *table, FILE * file){
        int size = strlen(string_key)+1;
        char string_buf[MAX_CHAR];
        fgets(string_buf, size, file);
        delete_end_of_line(string_buf);
        if(OK_key(string_key,string_buf))
        {
                fgets(string_buf,MAX_CHAR,file);
                size_t size_string = strlen(string_buf);
                delete_end_of_line(string_buf);
                if (string_buf[0] == '\"'&& string_buf[size_string-2] ==','&& string_buf[size_string-3] == '\"')
                {
                        for(int i = 0; i<strlen(string_buf); i++) {
                                string_buf[i]=string_buf[i+1];
                        }
                        string_buf[size_string-4]= '\0';
                        strcpy(table, string_buf);
                        return(true);
                }
        }
        return(false);
}
bool is_opinion (const char * op_key, struct node * new_element,FILE * file)
{
        int size = strlen(op_key)+1;
        char buf[size];
        int num_buf;
        fgets(buf, size, file);
        delete_end_of_line(buf);
        if(OK_key(op_key,buf))
        {
                fscanf(file, "%d", &num_buf);
                get_the_char(',',file);
                if(num_buf<=100 && num_buf>= 0)
                {
                        new_element->opinion = num_buf;
                        return (true);
                }
        }
        return(false);
}
bool is_enum (const char * enum_key,struct node * new_element, FILE * file)
{
        int size = strlen (enum_key)+1;
        char buf[size];
        int num_buf;
        fgets(buf, size, file);
        delete_end_of_line(buf);
        if(OK_key(enum_key,buf))
        {
                fscanf(file, "%d", &num_buf);
                get_the_char(',',file);
                if(num_buf<6 && num_buf>0)
                {
                        new_element->showtype = num_buf;
                        return (true);
                }
        }
        return(false);
}
int get_the_char(char ch, FILE * file)
{
        const int max_let =5;
        char c[max_let];
        fgets(c, max_let, file);
        if(c[0]==ch)
        {
                return (1);
        }
        return(0);
}
int OK_key (const char* key, char * string)
{
        size_t length_key = strlen(key);
        if(string[0] =='\"' && string[length_key-2]=='\"' && string[length_key-1]==':')
        {
                if (strncmp(string,key,length_key)==0)
                        return(1);
        }
        return(0);
}
FILE *  opening_the_file_read_t (char * file_name)
{
        FILE *file = fopen (file_name, "rt");
        if (file == NULL)
        {
                printf("Przykro mi nie można otworzyć pliku.\n");
                return (NULL);
        }
        printf("Udało się otworzyć plik!\n");
        return(file);
}

int checking_file (FILE * file)
{
        if(feof(file))
        {
                printf("Plik zakończony.\n\n\n");
                return (1);
        }
        if (ferror (file))
        {
                printf("Błąd obsługi pliku.\n\n\n");
                return(1);
        }
        return(0);
}
FILE * from_the_file_b(void)
{
        FILE *file;
        char file_name[MAX_CHAR];
        do {
                printf("Wczytywanie danych z plinku binarnego.\n");
                printf("Proszę podać nazwę pliku.\n");
                scanf("%s",file_name);
                file = opening_the_file_read_b(file_name);
        } while(file == NULL);
        return (file);
}
FILE * opening_the_file_write_b (char *file_name)
{
        FILE * file = fopen(file_name, "ab");
        if(file ==NULL) {
                printf("Przykro mi, nie udało się otworzyć pliku.\n");
                return(NULL);
        }
        printf("Udało się otworzyć plik\n");
        return(file);
}
FILE * opening_the_file_read_b (char *file_name)
{
        FILE * file = fopen(file_name, "rb");
        if(file ==NULL) {
                printf("Przykro mi, nie udało się otworzyć pliku.\n");
                return(NULL);
        }
        printf("Udało się otworzyć plik\n");
        return(file);
}
int how_many_items(size_t size_struct, FILE * file)
{
        fseek (file, 0, SEEK_END);
        long int fsize = ftell(file);
        fsize /= size_struct;
        rewind(file);
        return(fsize);
}
struct node * load_binary_data ( FILE *file, size_t size_struct)
{
        struct node * new_element = malloc(sizeof(struct node));
        if(!fread(new_element, size_struct,1,file)) {
                printf("Nie udało się wczytać danych z pliku binarnego\n");
                fclose(file);
                return(NULL);
        }
        print_information(new_element);
        return(new_element);
}
void save_to_binary (struct node * head)
{
        FILE * file;
        char file_name[MAX_CHAR];
        do {
                printf("Zapisywanie danych w pliku binarnym\n");
                printf("Podaj nazwę pliku, do którego chciałbyś zapisać dane\n");
                scanf("%s",file_name);
                file = opening_the_file_write_b(file_name);
        } while(file == NULL);
        if (save_binary_data(head, file)) {
                printf("Błąd przy zapisywaniu do pliku.\n\n\n");
        }else
                printf("Pomyślnie zapisano\n\n\n");
}
int save_binary_data (struct node * head, FILE * file)
{
        if(head ==NULL)
        {
                printf("Lista jest pusta.\n");
                return(1);
        }else
        {
                size_t struct_size = sizeof(struct node);
                struct node * temp = head;
                while (temp!=NULL)
                {
                        if(!fwrite(temp, struct_size, 1, file)) {
                                fclose(file);
                                return(1);
                        }
                        temp=temp->next;
                }
                fclose(file);
                return(0);
        }
}
char** make_actor_list(void){
        char buf[MAX_CHAR];
        FILE* file;
        do {
                printf("Podaj nazwę pliku w którym przechowywana jest lista zatrudnionych aktorów.\n");
                clean();
                fgets(buf,MAX_CHAR,stdin);
                delete_end_of_line(buf);
                file= opening_the_file_read_t(buf);
        } while(file==NULL);
        char ** name_actors = get_the_names(file);
        return(name_actors);
}
char ** get_the_names (FILE*file){
        char actor_key[]="\"AKTORZY\":";
        char temp[MAX_CHAR];
        char** name_actors = malloc(sizeof(char *)*MAX_CHAR);
        for(int i=0; i<MAX_CHAR && checking_file(file)==0; i++) {
                int result = get_the_char('{',file)&& is_string(actor_key,temp,file)&&get_the_char('}',file);
                if(result && !if_string(temp)&& !if_sign(temp)) {
                        name_actors[i]=malloc(sizeof(char)*MAX_CHAR);
                        strcpy(name_actors[i],temp);
                }
        }
        fclose(file);
        int size = how_many_actors(name_actors);
        bubblesort(name_actors,size);
        return(name_actors);
}
int if_sign (char* string){
        for(int i =0; i<strlen(string); i++) {
                if(iscntrl(string[i]))
                        return(1);
        }
        return(0);
}
void search_actor(char** name_actors, struct node * head){
        int size = how_many_actors(name_actors);
        for(int i = 0; i<size; i++) {
                printf("%d.%s\n",i+1,name_actors[i] );
        }
        printf("Czy chcesz sprawdzić czy dany aktor gra już w sztuce?\nY\\N\n");
        int answer = check_answer();
        if(answer == 'Y'|| answer == 'y') {
                choose_actor(name_actors, head);
        }else{
                for(int i =0; i<size; i++) {
                        free(name_actors[i]);
                }
                free(name_actors);
        }
}
void choose_actor (char ** name_actors, struct node * head){
        char buf[MAX_CHAR];
        int size = how_many_actors(name_actors);
        int choice;
        do {
                printf("Wybierz aktora, którego chcesz odszukać.\n____");
                scanf("%d", &choice);
                if(choice>size+1 || choice<0) {
                        printf("Przykro mi nie ma takiego numeru na liście.\n");
                }
        } while (choice>size+1 || choice<0);
        strcpy(buf,name_actors[choice-1]);
        printf("Wybrałeś: %s\n",buf);
        search_list_for_actor(head, buf);
        printf("Czy chcesz wyszukać innego aktora?\nY\\N___");
        int answer = check_answer();
        if(answer == 'Y'|| answer == 'y') {
                choose_actor(name_actors,head);
        }else{
                for(int i=0; i<size; i++) {
                        free(name_actors[i]);
                }
                free(name_actors);
        }
}
void search_list_for_actor(struct node * head, char * actor){
        struct node * temp = head;
        int size = strlen(actor);
        if(head == NULL) {
                printf("\n\n\nLista jest pusta!\n\n\n");
        }else{
                while(temp) {
                        if(strncmp(temp->actors[0],actor,size) == 0 || strncmp(temp->actors[1],actor,size)==0) {
                                printf("Znaleziono aktora:\n");
                                print_information(temp);
                                temp=temp->next;
                        }else
                                temp=temp->next;
                }
                if(temp==NULL) {
                        printf("Nie znaleziono.\n\n\n");
                }
        }
}
int how_many_actors(char ** name_actors){
        int i=0;
        while(name_actors[i]) {
                if(*name_actors[i]=='\n') {
                        free(name_actors[i]);
                }
                i++;
        }
        return(i);
}
