#include "main_menu.h"
#include "list_header.h"
void alphabetical_order (struct node * head)
{
        if(head == NULL) {
                printf("Lista jest pusta.\n");
        }else {
                int size = list_size(head);
                char ** titles = malloc(sizeof(char*)*size);
                struct node * temp = head;
                for(int i =0; i<size; i++) {
                        titles[i]= malloc(sizeof(char)*MAX_CHAR);
                        strcpy(titles[i], temp->title);
                        temp=temp->next;
                }
                bubblesort(titles, size);
                printf("Alfabetyczna lista tytułów:\n\n");
                for(int i =0; i<size; i++) {
                        printf("%d.%s\n",i+1,titles[i]);
                }
                for(int j=0; j<size; j++) {
                        free(titles[j]);
                }
                free(titles);
        }
}
void bubble_swap(char **x, char **y)
{
        char *tmp=*x;
        *x=*y;
        *y=tmp;
}
void bubblesort(char ** titles, int size){
        for(int i = 0; i<size-1; i++) {
                for(int j = 0; j<size-i-1; j++) {
                        if(strncmp(titles[j],titles[j+1],MAX_CHAR)>0) {
                                bubble_swap((titles+j),(titles+j+1));
                        }
                }
        }
}
struct node * add_element(struct node * head, struct node * tail)
{
        struct node * new_element = malloc(sizeof(struct node));
        add_information(new_element);
        new_element->next = head;
        new_element->prev = NULL;
        head =new_element;
        if(new_element->next)
        {
                new_element->next->prev= new_element;
        }else{
                tail=new_element;
        }
        printf("Dodano element\n\n\n\n");
        return (head);

}
struct node * search_element (struct node *head, struct node * tail)
{
        char to_search[MAX_CHAR];
        printf("Podaj nazwę elementu który chciałbyś wyszukać\n");
        do {
                clean();
                fgets(to_search, MAX_CHAR, stdin);
                delete_end_of_line(to_search);
                if(if_string(to_search))
                {
                        printf("Przykro mi to nie jest nazwa przedstawienia, spróbuj jeszcze raz.\n");
                        clean();
                }
        } while (if_string(to_search));
        if(head == NULL)
        {
                printf("Lista jest pusta\n");
        }
        struct node * temp = head;
        while(temp!=NULL)
        {
                if(strcmp(temp->title,to_search) == 0)
                {
                        printf("Znaleziono element.\n");
                        return(temp);
                } else{
                        temp = temp->next;
                }
        }
        printf("Przykro mi, nie znaleziono elementu.\n");
        return(NULL);
}
void edit_element(struct node * to_edit){
        clrscrs();
        printf("Chcesz edytować ten element.\n");
        print_information(to_edit);
        printf("Czy chcesz edytować tytuł?\nY\\N\n___");
        int answer = check_answer();
        if(answer=='Y'|| answer=='y')
                while(add_title(to_edit));
        printf("Czy chcesz edytować typ przedstawienia?\nY\\N\n___");
        answer = check_answer();
        if(answer=='Y'|| answer=='y')
                while(add_type(to_edit));
        printf("Czy chcesz edytować opinię o przedstawieniu?\nY\\N\n___");
        answer = check_answer();
        if(answer=='Y'|| answer=='y')
                while(add_opinion(to_edit));
        printf("Czy chcesz edytować aktorów?\nY\\N\n___");
        answer = check_answer();
        if(answer=='Y'|| answer=='y')
                while(add_actors(to_edit));
        printf("Pomyślnie edytowano.\n");
}
int check_answer(void){
        char answer;
        do {
                scanf("%c",&answer);
        } while(is_it_yes(answer));
        return(answer);
}
int is_it_yes(char c){
        if(c=='y'|| c=='Y'|| c=='n'|| c=='N')
                return(0);
        if(c=='\n')
                return(1);
        printf("Przykro mi podano nieprawidłowy znak.\n");
        return(1);
}
void delete_element (struct node * head, struct node * to_del, struct node * tail)
{
        if(to_del->prev != NULL )
        {
                to_del->prev->next = to_del->next;
        }else
        {
                head = to_del->next;
        }
        if (to_del->next != NULL)
        {
                to_del->next->prev= to_del->prev;
        }else
        {
                tail = to_del->prev;
        }
        free_the_memory(to_del);
}
int list_size(struct node *head)
{
        unsigned int size=0;
        struct node * temp = head;
        while(temp!=NULL)
        {
                ++size;
                temp= temp->next;
        }
        return (size);
}
void delete_element_name(struct node *head, struct node * tail)
{
        struct node * to_del = search_element(head,tail);
        if(to_del == NULL)
                exit(1);
        delete_element(head,to_del,tail);
}
void show(struct node * head)
{
        if (head == NULL)
        {
                printf("Lista jest pusta\n\n\n");
        }
        struct node * temp = head;
        while(temp!= NULL)
        {
                print_information(temp);
                temp=temp->next;
        }
}
struct node * unite(struct node * head, struct node * new_element, struct node * tail)
{
        new_element->next = head;
        new_element->prev = NULL;
        head = new_element;
        if(new_element->next)
        {
                new_element->next->prev= new_element;
        }else{
                tail=new_element;
        }
        return(head);
}
struct node * sorting_list (struct node ** head,int (*function)(struct node * node1,struct node * node2))
{
        if(*head == NULL) {
                printf("Lista jest pusta!\n");
        }else if ((*head)->next == NULL) {
                printf("Posortowana lista:\n");
                print_information(*head);
        }else{
                int size = list_size(*head);
                struct node ** pointer_table = malloc(sizeof(struct node *)*size);
                struct node * temp =*head;
                for(int i =0; i<size; i++) {
                        pointer_table[i]=temp;
                        temp=temp->next;
                }
                for(int i = size-1; i>0; i--) {
                        for(int j=0; j<i; j++)
                        {
                                if(function(pointer_table[j], pointer_table[j+1])==1) {
                                        struct node * temp = pointer_table[j+1];
                                        pointer_table[j+1] = pointer_table[j];
                                        pointer_table[j]= temp;
                                }
                        }
                }
                decomposition(pointer_table,size);
                composition(pointer_table, size);
                *head=pointer_table[0];
                printf("***************************************\n\n");
                printf("A oto posortowana lista:\n\n");
                printf("***************************************\n");
                show(*head);
                free(pointer_table);
        }
        return  (*head);
}
void decomposition (struct node ** table, int size){
        for(int i =0; i<size; i++) {
                table[i]->next = NULL;
                table[i]->prev = NULL;
        }
}
void composition (struct node ** table,int size){
        table[0]->prev=NULL;
        table[0]->next = table[1];
        for(int i = 1; i<size-1; i++) {
                table[i]->next = table[i+1];
                table[i]->prev= table[i-1];
        }
}
int compare_opinion(struct node * node1, struct node * node2){
        if(node1->opinion > node2->opinion) {
                return(1);
        }else if(node1->opinion == node2->opinion) {
                return(0);
        }
        return(-1);
}
int compare_enum (struct node * node1, struct node * node2){
        if(node1->showtype > node2->showtype) {
                return(1);
        } if(node1->showtype == node2->showtype) {
                return(0);
        }
        return(-1);
}
void clrscrs(void){
        system("@cls||clear");
}
