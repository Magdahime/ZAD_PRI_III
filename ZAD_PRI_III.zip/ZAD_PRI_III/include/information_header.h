#include "main_menu.h"
#ifndef information_header_h
#define information_header_h
void alphabetical_order (struct node * head);
void bubble_swap(char **x, char **y);
struct node * add_information(struct node * node1);
void free_the_memory (struct node *element);
int if_enum(void);
#endif
