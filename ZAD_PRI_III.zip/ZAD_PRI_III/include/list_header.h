#include "main_menu.h"
#ifndef list_header_h
#define list_header_h
void edit_element(struct node * to_edit);
void delete_element_name(struct node *head, struct node * tail);
int list_size(struct node *head);
struct node * add_element(struct node *head, struct node * tail);
struct node * add_information(struct node * node1);
void delete_element (struct node * head,struct node * to_del, struct node * tail);
struct node * search_element (struct node *head, struct node *tail);
struct node * sorting_list (struct node ** head,int (*function)(struct node * node1,struct node * node2));
void decomposition (struct node ** table,int size);
void composition (struct node ** table, int size);
int compare_opinion(struct node * node1, struct node * node2);
int compare_enum (struct node * node1, struct node * node2);
int is_it_yes(char c);
void free_the_memory (struct node *element);
#endif
