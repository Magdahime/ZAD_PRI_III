#ifndef main_menu_h
#define main_menu_h
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX_CHAR 100
#define MAX_ROWS 2
enum show_type {PRZEDSTAWIENIE=1, OPERA, OPERETKA, BALET, PANTOMIMA};
struct node {
        unsigned int opinion;
        enum show_type showtype;
        char title[MAX_CHAR];
        char actors[MAX_ROWS][MAX_CHAR];
        struct node *prev, *next;
};
void user_interface(void);
void clrscrs(void);
void clean(void);
void bubblesort(char ** titles, int size);
void delete_end_of_line (char * buffer);
int if_string(char * information_array);
int check_answer(void);
int add_title(struct node *node1);
int add_type(struct node *node1);
int add_opinion(struct node *node1);
int add_actors(struct node * node1);
void print_information(struct node *node1);
void show(struct node* head);
#endif
