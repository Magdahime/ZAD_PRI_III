#ifndef file_header_h
#define file_header_h
FILE * from_the_file_t(void);
FILE *  opening_the_file_read_t (char * file_name);
FILE *  opening_the_file_write_t (char * file_name);
int checking_file (FILE * file);
void data_to_structure (char ** buff_array, struct node * head, struct node * tail);
bool is_string(char* string_key, char * table, FILE * file);
bool is_opinion (const char * op_key, struct node * new_element,FILE * file);
bool is_enum (const char * enum_key, struct node * new_element, FILE * file);
void connecting_elements(struct node * new_element, struct node * head, struct node * tail);
int print_data_to_file (struct node * head, FILE * file,struct node * tail);
void save_data_to_file (struct node * head, struct node * tail);
struct node * load_data (FILE *file);
int OK_key (const char* key, char * string);
int get_the_char (char ch, FILE * file);
struct node * unite(struct node * head, struct node * new_element, struct node *tail);
struct node * load_binary_data (FILE *file, size_t size_struct);
FILE * from_the_file_b(void);
FILE * opening_the_file_read_b (char *file_name);
FILE * opening_the_file_write_b (char* file_name);
int save_binary_data (struct node * head, FILE * file);
void save_to_binary(struct node * head);
int how_many_items(size_t size_struct, FILE * file);
char** make_actor_list(void);
char ** get_the_names (FILE*file);
void search_actor(char** name_actors, struct node * head);
int how_many_actors(char ** name_actors);
void search_list_for_actor(struct node * head, char * actor);
void choose_actor (char ** name_actors, struct node * head);
int if_sign (char* string);
void free_the_memory (struct node *element);
#endif
